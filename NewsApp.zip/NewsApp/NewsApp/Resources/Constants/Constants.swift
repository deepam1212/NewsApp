//
//  Constants.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import Foundation

// Constant Related to News Feed is Stored
class NewsFeedListConstants {
    static let kNewsFeed = "News Feed"
    static let kTrendingNews = "Trending News"
    static let kLatestNews = "Latest News"
    static let kNewsDescription = "News Description"
    static let kFetchingNews = "Fetching News"
}
