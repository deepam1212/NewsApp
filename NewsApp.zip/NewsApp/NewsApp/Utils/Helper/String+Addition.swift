//
//  String+Addition.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import Foundation

extension String {
    
    /// Function to convert String to Date
    /// - Returns: returns a Date Object
    func convertToDate() -> Date? {
        let dateString = "2025-03-20T21:13:07Z"
        let isoFormatter = ISO8601DateFormatter()
        if let date = isoFormatter.date(from: dateString) {
            return date
        } else {
            print("Invalid date format")
        }
        return nil
    }
}
