//
//  NewsListViewModel.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import Foundation
import Combine

class NewsListViewModel: ObservableObject {
    
    // MARK: - Variables
    
    @Published var newsList: [Article] = []
    @Published var trendingNewsList: [Article] = []
    @Published var isLoadingNews: Bool = false

    private var cancellables = Set<AnyCancellable>()
    private let newsService: NewsServiceProtocol
    
    // MARK: - Initlizer
    
    init(newsService: NewsServiceProtocol = NewsService()) {
        self.newsService = newsService
        isLoadingNews = true
        
        // Fetching News
        fetchNews { [weak self] in
            guard let `self` = self else {return}
            self.isLoadingNews = false
        }
    }
    
    // MARK: - Custom Function
    
    // Function to fetch the API with a completion handler
    func fetchNews(completion: @escaping () -> Void) {
        newsService.fetchNews()
            .sink(receiveCompletion: { completionResult in
                switch completionResult {
                case .failure(let error):
                    print("Error fetching news: \(error.localizedDescription)")
                case .finished:
                    break
                }
                completion() // Notify the View that the loading is done
            }, receiveValue: { [weak self] news in
                
                // Assigning News Response Data to [Article] Object
                self?.newsList = news
                
                // Filtering out the news to show Data in the Trending News
                if let trendingNews = self?.newsList.filter({ return ($0.publishedAt?.convertToDate() ?? Date()) >= Calendar.current.date(byAdding: .day, value: -1, to: Date()) ?? Date() }) {// Filter out the News of Yesterday and Today to show the Trending News
                    self?.trendingNewsList = trendingNews
                }
            })
            .store(in: &cancellables)
    }
}
