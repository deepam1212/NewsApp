//
//  NewsService.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import Foundation
import Combine

// Protocol to define the Network function
protocol NewsServiceProtocol: AnyObject {
    func fetchNews() -> AnyPublisher<[Article], Error>
}

class NewsService: NewsServiceProtocol {
    
    // MARK: - Variable
    
    private let baseURL = "https://newsapi.org/v2/top-headlines?country=us&apiKey=4a066ef483d14a469b3677b3036e0f19"
    
    // MARK: - Custom Function
    
    /// function to Fetch the News
    /// - Returns: return the Array of [Article] and Error
    func fetchNews() -> AnyPublisher<[Article], Error> {
        guard let url = URL(string: baseURL) else {
            return Fail(error: URLError(.badURL)).eraseToAnyPublisher()
        }
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data)
            .handleEvents(receiveOutput: { data in
                    print(String(data: data, encoding: .utf8) ?? "Invalid Data")
                })
            .decode(type: NewsResponse.self, decoder: JSONDecoder())
            .map { $0.articles }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}
