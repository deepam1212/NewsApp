//
//  NewsAppApp.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import SwiftUI

@main
struct NewsAppApp: App {
    var body: some Scene {
        WindowGroup {
            NewsListView()
                .preferredColorScheme(.dark)// Forcing App to be in the Dark Mode
        }
    }
}
