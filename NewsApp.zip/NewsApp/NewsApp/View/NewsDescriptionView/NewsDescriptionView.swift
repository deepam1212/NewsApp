//
//  NewsDescriptionView.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import SwiftUI

// MARK: - NewsDescriptionView
/// This View Displays the Detailed Description of a News Article
struct NewsDescriptionView: View {
    
    // MARK: - Prperty Wrapper
    
    /// Controls whether the detail view is shown or hidden
    @Binding var isShowingDetail: Bool
    
    // MARK: - Variable
    
    /// News article to be displayed
    let news: Article
    
    // MARK: - Body
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                
                // MARK: - Close Button
                if isShowingDetail {
                    closeButton
                        .padding(.top, 10)
                }
                
                // MARK: - News Image
                if let imageUrl = news.urlToImage,
                   let url = URL(string: imageUrl) {
                    AsyncImage(url: url) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 200)
                    .cornerRadius(8)
                }
                
                // MARK: - Likes and Comments
                likesAndCommentsView
                
                // MARK: - News Title
                if let newsTitle = news.title {
                    Text(newsTitle.trimmingCharacters(in: .whitespacesAndNewlines))
                        .font(.system(size: 21, weight: .bold))
                        .foregroundStyle(Color.primary)
                }
                
                // MARK: - News Description
                if let newsDescription = news.description {
                    Text(newsDescription.trimmingCharacters(in: .whitespacesAndNewlines))
                        .font(.system(size: 17, weight: .regular))
                        .foregroundStyle(Color.primary)
                }

                Spacer()
            }
            .padding(20)
        }
    }
    
    // MARK: - Likes and Comments View
    private var likesAndCommentsView: some View {
        HStack(spacing: 10) {
            // Likes
            HStack(spacing: 5) {
                Image(systemName: "heart.fill")
                    .foregroundColor(.red)
                Text("0")
                    .font(.system(size: 16, weight: .medium))
            }
            
            // Comments
            HStack(spacing: 5) {
                Image(systemName: "bubble.right.fill")
                    .foregroundColor(.blue)
                Text("0")
                    .font(.system(size: 16, weight: .medium))
            }
            Spacer()
        }
        .padding(.vertical, 10)
    }

    // MARK: - Close Button View
    private var closeButton: some View {
        HStack {
            Button(action: {
                withAnimation(.easeInOut(duration: 0.4)) {
                    isShowingDetail = false
                }
            }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
                    .foregroundColor(.primary)
            }
            Spacer()
        }
    }
}

// MARK: - NewsDescriptionPreview
struct NewsDescriptionPreview: View {
    @State var isShow: Bool = true
    var body: some View {
        VStack {
            NewsDescriptionView(isShowingDetail: $isShow, news: Article(id: "", source: Source(name: ""), author: "", title: "News Title", description: "News Description", urlToImage: "", content: "", publishedAt: ""))
        }
    }
}

#Preview {
    NewsDescriptionPreview()
}
