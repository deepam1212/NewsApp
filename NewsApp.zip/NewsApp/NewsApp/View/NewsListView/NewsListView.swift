//
//  NewsListView.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import SwiftUI

struct NewsListView: View {
    
    // MARK: - Prperty Wrapper
    
    // Model Object in which the Api and Business Logic is Stored
    @StateObject private var newsViewModel: NewsListViewModel = NewsListViewModel()
    
    /// Tracks loading the state
    @State private var isLoading: Bool = true
    
    
    // MARK: - Body
    
    var body: some View {
        NavigationView {
            ZStack {
                if newsViewModel.isLoadingNews {
                    // Show Loader
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle())
                        .scaleEffect(1.5)
                } else {
                    // Show News List
                    List {
                        // MARK: - Trending News Section (Horizontal Scroll)
                        Section(header: trendingNewsHeader) {
                            TrendingNewsView(newsArticle: newsViewModel.trendingNewsList)
                        }
                        
                        // MARK: - Latest News Section (Vertical List)
                        Section(header: latestNewsHeader) {
                            ForEach(newsViewModel.newsList) { news in
                                LatestNewsRow(news: news)
                            }
                        }
                    }
                    .listStyle(GroupedListStyle()) // Set grouped list style
                    .navigationTitle(NewsFeedListConstants.kNewsFeed) // Set navigation title
                    .background(Color.gray.opacity(0.1)) // Background color for contrast
                }
            }
        }
    }
    
    // MARK: - Section Headers
    
    /// Trending News Header View
    private var trendingNewsHeader: some View {
        Text(NewsFeedListConstants.kTrendingNews)
            .font(.system(size: 21, weight: .bold))
            .foregroundStyle(Color.primary)
            .padding(.top, 10)
    }
    
    /// Latest News Header View
    private var latestNewsHeader: some View {
        Text(NewsFeedListConstants.kLatestNews)
            .font(.system(size: 21, weight: .bold))
            .foregroundStyle(Color.primary)
            .padding(.top, 10)
    }
}

#Preview {
    NewsListView()
}
