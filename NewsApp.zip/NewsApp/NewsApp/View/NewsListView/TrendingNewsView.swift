//
//  TrendingNewsView.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import SwiftUI

// MARK: - Trending News View (Horizontal Scroll)
struct TrendingNewsView: View {
    
    // MARK: - Variable
    
    // Object of [Article] Model through which we will be showing Data on the UI
    let newsArticle: [Article]
    
    // selectedNews which is to be Shown on NewsDescriptionView
    @State private var selectedNews: Article?
    
    // State to show/ hide the detail View
    @State private var isShowingDetail = false
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 15) {
                ForEach(newsArticle) { news in
                    TrendingNewsCard(news: news)
                        .onTapGesture {
                            withAnimation(.easeInOut(duration: 0.4)) {
                                selectedNews = news
                                isShowingDetail = true
                            }
                        }
                }
            }
            .padding(.horizontal)
        }
        .listRowInsets(EdgeInsets())
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
        if isShowingDetail, let selectedNews = selectedNews {
            NewsDescriptionView(isShowingDetail: $isShowingDetail, news: selectedNews)
                .transition(.move(edge: .trailing))
                .animation(.easeInOut(duration: 0.4), value: isShowingDetail)
                .zIndex(1)
        }
    }
}

// MARK: - Trending News Card
struct TrendingNewsCard: View {
    
    // MARK: - Variable
    
    /// News article to be displayed
    let news: Article
    
    // MARK: - Body
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if let imageUrl = news.urlToImage,
               let url = URL(string: imageUrl) {
                AsyncImage(url: url) { image in
                    image.resizable()
                } placeholder: {
                    ProgressView()
                }
                .frame(height: 120)
                .cornerRadius(8)
            } else {
                Image(systemName: "photo") // Default placeholder for missing URL
                    .resizable()
                    .scaledToFit()
                    .foregroundColor(.gray)
                    .frame(height: 120)
                    .cornerRadius(8)
            }
            
            if let newsTitle = news.title {
                Text(newsTitle.trimmingCharacters(in: .whitespacesAndNewlines))
                    .font(.headline)
                    .foregroundStyle(Color.black)
                    .lineLimit(2)
            }
        }
        .padding(8)
        .frame(width: 180)
        .frame(maxHeight: .infinity)
        .background(Color.white)
        .cornerRadius(11)
    }
}

#Preview {
    TrendingNewsView(newsArticle: [Article(id: "", source: Source(name: ""), author: "", title: "News Title", description: "News Description", urlToImage: "", content: "", publishedAt: "")])
}
