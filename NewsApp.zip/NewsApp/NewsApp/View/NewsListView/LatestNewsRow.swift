//
//  LatestNewsRow.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import SwiftUI

// MARK: - Latest News Row
struct LatestNewsRow: View {
    
    // MARK: - Prperty Wrapper

    @State private var isShownDetailView: Bool = false
    
    // MARK: - Variable
    
    /// News article to be displayed
    let news: Article
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 11)
                .fill(Color.white)
                .shadow(radius: 2)
            
            HStack {
                VStack(alignment: .leading, spacing: 10) {
                    if let newsTitle = news.title {
                        Text(newsTitle.trimmingCharacters(in: .whitespacesAndNewlines))
                            .font(.system(size: 21, weight: .bold))
                            .foregroundStyle(Color.black)
                            .lineLimit(2)
                    }
                    
                    if let newsDescription = news.description {
                        Text(newsDescription.trimmingCharacters(in: .whitespacesAndNewlines))
                            .font(.system(size: 17, weight: .regular))
                            .foregroundStyle(Color.blue)
                            .lineLimit(2)
                    }
                }
                Spacer()
                if let imageUrl = news.urlToImage,
                   let url = URL(string: imageUrl) {
                    AsyncImage(url: url) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(width: 120, height: 120)
                    .cornerRadius(8)
                } else {
                    Image(systemName: "photo") // Default placeholder for missing URL
                        .resizable()
                        .scaledToFit()
                        .foregroundColor(.gray)
                        .frame(width: 120, height: 120)
                        .cornerRadius(8)
                }
                Image(systemName: "chevron.right")
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
            }
            .padding(8)
        }
        .listRowSeparator(.hidden)
        .listRowBackground(Color.clear)
        .background(
            NavigationLink(destination: NewsDescriptionView(isShowingDetail: $isShownDetailView, news: news)) {
                EmptyView()
            }
            .opacity(0)
        )
    }
}
#Preview {
    LatestNewsRow(news: Article(id: "", source: Source(name: ""), author: "", title: "News Title", description: "News Description", urlToImage: "", content: "", publishedAt: ""))
}
