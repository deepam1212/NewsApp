//
//  NewsModel.swift
//  NewsApp
//
//  Created by Deepam Sharma on 3/21/25.
//

import Foundation

// MARK: - NewsResponse
struct NewsResponse: Codable {
    let status: String?
    let totalResults: Int?
    let articles: [Article]
}

// MARK: - Article
struct Article: Codable, Identifiable {
    let id: String?
    let source: Source
    let author, title, description: String?
    let urlToImage: String?
    let content: String?
    let publishedAt: String?
    
    enum CodingKeys: String, CodingKey {
           case id = "url"
           case source, author, title, description, urlToImage, content, publishedAt
       }
}

// MARK: - Source
struct Source: Codable {
    let name: String
}
