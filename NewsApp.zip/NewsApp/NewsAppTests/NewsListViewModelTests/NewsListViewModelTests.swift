//
//  NewsListViewModelTests.swift
//  NewsAppTests
//
//  Created by Deepam Sharma on 03/21/25.
//

import XCTest
import Combine
@testable import NewsApp

final class NewsListViewModelTests: XCTestCase {
    
    var viewModel: NewsListViewModel!
    var mockNewsService: MockNewsService!
    var cancellables: Set<AnyCancellable>!
    
    override func setUp() {
        super.setUp()
        mockNewsService = MockNewsService()
        viewModel = NewsListViewModel(newsService: mockNewsService)
        cancellables = []
    }
    
    override func tearDown() {
        viewModel = nil
        mockNewsService = nil
        cancellables = nil
        super.tearDown()
    }
    
    // MARK: - Test Cases
    
    func test_FetchNews_Success() {
        let expectedArticles = [
            Article(id: "1", source: Source(name: "ZeeNews.com"), author: "Author1", title: "Breaking News", description: "News Description", urlToImage: "image_url", content: "News Content", publishedAt: ""),
            Article(id: "2", source: Source(name: "Star.com"), author: "Author2", title: "Tech News", description: "Tech Description", urlToImage: "image_url2", content: "Tech Content", publishedAt: "")
        ]
        mockNewsService.mockResult = .success(expectedArticles)
        
        let expectation = XCTestExpectation(description: "Fetching news updates the list")
        
        viewModel.$newsList
            .dropFirst()
            .sink { articles in
                XCTAssertEqual(articles.count, expectedArticles.count, "News list count should match expected")
                XCTAssertEqual(articles.first?.title, "Breaking News", "First article title should match")
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        viewModel.fetchNews {}

        wait(for: [expectation], timeout: 2.0)
    }
    
    func test_LoadingState() {
        mockNewsService.mockResult = .success([])

        let expectation = XCTestExpectation(description: "Loading state updates correctly")

        viewModel.$isLoadingNews
            .sink { isLoading in
                if !isLoading {
                    expectation.fulfill()
                }
            }
            .store(in: &cancellables)

        viewModel.fetchNews {}

        wait(for: [expectation], timeout: 4.0)
    }
}

// MARK: - Mock News Service
class MockNewsService: NewsServiceProtocol {
    var mockResult: Result<[Article], Error> = .success([])
    
    func fetchNews() -> AnyPublisher<[Article], Error> {
        return Future { promise in
            promise(self.mockResult)
        }
        .eraseToAnyPublisher()
    }
}

